// Test Transatction rollback by yarzartun
var express = require('express');
var app 	= express();
var compress = require('compression');
var bodyParser = require('body-parser');

var port 	= process.env.PORT || 4000;
app.set('view engine', 'ejs');
app.use(compress());
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded( {extended : true} ));
app.use(require('./controllers'));

app.listen(port, function() {
  console.log('Listening on port ' + port);
});