// Test Transatction rollback by yarzartun
var express	= require('express');
var router	= express.Router();

router.get('/', function(req, res) {	
	res.render('index',{data:""});
});

router.use('/user', require('./user'));

module.exports = router;