// Test Transatction rollback by yarzartun
var express = require('express');
var router = express.Router();
var user_model = require('../models/user_model');

router.post('/send', function(req, res) {
    var params = req.body;
    console.log(params);
    user_model.save_user(params, function(err, result) {
        if(err)
        {
            console.log(err);
             res.render('index',{data:"Transatction Fail"});
        }
        else{
            res.render('index',{data:result});
        }
    });
});

module.exports = router;
