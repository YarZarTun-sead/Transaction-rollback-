// Test Transatction rollback by yarzartun
var mysql = require('mysql');

var pool  = mysql.createPool({
    connectionLimit : 10,
    host: 'localhost',
    user: 'root',
    password : 'root',
    port : 3306,
    database:'db_test_transaction',
    multipleStatements:true
});

var getConnection = function(callback) {
    pool.getConnection(function(err, connection) {
        callback(err, connection);
    });
};

exports.getConnection = getConnection;