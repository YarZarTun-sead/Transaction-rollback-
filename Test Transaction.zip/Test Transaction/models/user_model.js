// Test Transatction rollback by yarzartun
var db = require('../helpers/database');

exports.save_user = function (params,cb) {
	console.log("params")
	console.log(params)
	var name = params.name;
	var phone = params.phone;
	var save_user = "INSERT INTO `user` SET name=?,phone=?;";

	db.getConnection(function (err, connection) {
		if(err){
			cb(err);
		}else{
			connection.beginTransaction(function(err1) {
				if(err1){
					cb(err1);
				}
				connection.query(save_user,[name,phone], function (err2, result) {
					//connection.release();
					if (!err2) {
						var save_admin = "INSERT INTO `admin` SET name=?,phone=?;";
						connection.query(save_admin,[name,phone], function (err3, result2) {
							if (!err3) {
								connection.commit(function(err4) {
							        if (err4) { 
							          connection.rollback(function() {
							          	console.log("this is rollback 4");
							            cb(err4);
							          });
							        }else{
							        	//connection.release();
							        	console.log("beginTransaction is success");
							        	cb(null,"Now Test Transaction is success.");
							        }
							    });//transaction commit
							}else{
								console.log("this is rollback 3");
								connection.rollback(function() {
							        cb(err3);
							    });
							}
						});//transaction 2
					} else {
						console.log("this is rollback 2");
						connection.rollback(function() {
					        cb(err2);
					    });
					}
				});//transaction 1
			})
		}
	});
}